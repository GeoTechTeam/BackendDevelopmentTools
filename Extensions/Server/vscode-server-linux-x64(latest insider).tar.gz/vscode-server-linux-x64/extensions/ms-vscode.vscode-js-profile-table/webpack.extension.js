module.exports = require('../../scripts/webpack.extension')(__dirname);
